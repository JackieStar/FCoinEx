//日志输出类
var JSConsole=
{ 
    Chart:{ Log:console.log, Warn:console.warn },      //图形日志
    Complier:{ Log:console.log, Warn:console.warn },   //编译器日志
};

module.exports =
{
    JSConsole:
    {
        Chart: JSConsole.Chart,
        Complier:JSConsole.Complier
    }
};